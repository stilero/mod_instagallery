<?php
/**
 * Image types
 *
 * @version  1.0
 * @package Stilero
 * @subpackage mod_instagallery
 * @author Daniel Eliasson <daniel at stilero.com>
 * @copyright  (C) 2013-sep-29 Stilero Webdesign (http://www.stilero.com)
 * @license	GNU General Public License version 2 or later.
 * @link http://www.stilero.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access'); 

class InstaObjectImageTypes{
    
    const LOW_RESOLUTION = 'low_resolution';
    const THUMBNAIL = 'thumbnail';
    const STANDARD_RESOLUTION = 'standard_resolution';
}
