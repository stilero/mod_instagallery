<?php
/**
 * @package	Instagram Module
 * @subpackage	mod_instagram
 * @copyright	Copyright (C) 2012 Stilero Webdesign. All rights reserved.
 * @license	GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;$document = JFactory::getDocument();
if(isset($list) && !empty($list)){ 
    require JModuleHelper::getLayoutPath('mod_instagallery', $galleryType);
} ?>